// pages/detail/detail.js

const app = getApp();
const api = require('../../config/config.js');

Page({

    /**
     * 页面的初始数据
     */
    data: {
      detailList: [],        // 评论列表
      ticketList: [],
      showInfo: {},           // 书籍信息
      detailLoading: true,
      buyDialogVisible: false,
      ticketsLoading: true,
      windowHeight: 300,
      curTicketId: -1,
      count: 1,
      totalPrice: 0,
      minCount: 1,
      maxCount: 0,
      curTicket: {}
    },
    // 获取演出详情信息
    getPageData: function() {

      let that = this;
      let requestData = {
          showId: that.data.showInfo.id
      };
      // setTimeout(function () {
      //   that.setData({
      //     detailList: [{
      //       type: 'image',
      //       value: 'https://pimg.dmcdn.cn/perform/project/1658/165802_n.jpg'
      //       }, {
      //         type: 'image',
      //         value: 'https://damaipimg.oss-cn-beijing.aliyuncs.com/cfs/src/5ad7381a-8d48-4589-b00d-ce5a069837af'
      //       }, {
      //         type: 'text',
      //         value: '草东没有派对'
      //       }, {
      //         type: 'image',
      //         value: 'https://damaipimg.oss-cn-beijing.aliyuncs.com/cfs/src/b0b29541-ff7c-49bb-a35a-ffd3a53f826a'
      //       }, {
      //         type: 'text',
      //         value: '来自台北的草东没有派对，在去年的金曲奖上，一鼓作气夺下了最 佳新人奖、年度歌曲奖、最 佳乐团奖三项大奖，是华语乐坛最不可估量的新晋乐团之一。他们的巡演更因为场场爆满、一票难求，被观众冠上了"草东没有门票"的戏称，这次登上厦门简单生活节是他们2018年第一次在厦门演出，也很可能是唯一一次，机会难得。'
      //       }],
      //     detailLoading: false
      //   });
      // }, 500);

        wx.request({
          url: api.queryShowUrl,
          method: 'GET',
          data: requestData,
            success: function(res) {
                if (res.data.result) {
                    that.setData({
                        detailList: res.data.data || []
                    });
                    setTimeout(function() {
                        that.setData({
                            detailLoading: false
                        });
                    }, 500);
                } else {
                    that.showInfo('返回数据异常');
                }
            },
            fail: function(error) {
                that.showInfo('请求失败');
            }
        });
    },


    showInfo: function(info, icon = 'none') {
        wx.showToast({
            title: info,
            icon: icon,
            duration: 1500,
            mask: true
        });
    },
    showBuyDialog () {
      this.getShowTickets();
      this.setData({
        buyDialogVisible: true
      });
    },
  hideBuyDialog() {
      this.setData({
        buyDialogVisible: false
      });
  },
  // 获取演出详情信息
  getShowTickets: function () {
    console.info('getShowTickets')
    let that = this;
    let requestData = {
      showId: that.data.showInfo.id
    };
    setTimeout(function () {
      that.setData({
        ticketList: [{
          id: 2,
          name: '普通票',
          price: 200,
          restCount: 100
        }, {
          id: 3,
          name: 'VIP套票',
          price: 500,
          restCount: 100
        }],
        ticketsLoading: false
      });
    }, 500);
    this.setCurTicket();
    // wx.request({
    //   url: api.queryTicketsUrl,
    //   method: 'GET',
    //   data: requestData,
    //     success: function(res) {
    //         if (res.data.result) {
    //             that.setData({
    //                 ticketList: res.data.data || []
    //             });
    //             that.setCurTicket();
    //             setTimeout(function() {
    //                 that.setData({
    //                     ticketsLoading: false
    //                 });
    //             }, 500);
    //         } else {
    //             that.showInfo('返回数据异常');
    //         }
    //     },
    //     fail: function(error) {
    //         that.showInfo('请求失败');
    //     }
    // });
  },

  setCurTicket() {
    let ticket = this.data.ticketList.find(tick => tick.restCount > 0);
    let restCount = ticket ? ticket.restCount : 0;
    let ticketId = ticket ? ticket.id : -1;
    this.setData({
      maxCount: restCount,
      curTicketId: ticketId
    });
  },
  getTicketItem (id) {
    return this.data.ticketList.find(tick => tick.id == id)
  },
  changeTicket (ev) {
    console.info('changeTicket:', ev.detail.value)
    let ticket = this.getTicketItem(ev.detail.value)
    this.setData({
      curTicketId: ev.detail.value,
      maxCount: ticket.restCount,
      curTicket: ticket,
      totalPrice: this.data.count * ticket.price
    });
  },
  handleCountChange (val) {
    this.setData({
      totalPrice: val.detail * this.data.curTicket.price
    });
  },
  gotoBuy () {
    //下订单
    let that = this;
    let requestData = {
      showId: that.data.showInfo.id,
      total: that.data.totalPrice,
      orderTickets: [{
        ticketId: that.data.curTicket.id,
        amount: that.data.count
      }]
    }
    console.info('gotoBuy:', requestData);
    wx.request({
      url: api.addOrder,
      method: 'POST',
      data: requestData,
      success: function(res) {
          if (res.data.result === 0) {
              that.setData({
                  ticketList: res.data.data || []
              });
              setTimeout(function() {
                  that.setData({
                      ticketsLoading: false
                  });
              }, 500);
          } else {
              that.showInfo('返回数据异常');
          }
      },
      fail: function(error) {
          that.showInfo('请求失败');
      }
    });
  },
  confirmBuyBook: function () {
    let that = this;
    wx.showModal({
      title: '提示',
      content: '确定用1积分兑换此书吗？',
      showCancel: true,
      cancelText: '打扰了',
      cancelColor: '#8a8a8a',
      confirmText: '确定',
      confirmColor: '#1AAD19',
      success: function (res) {
        if (res.confirm) {
          // 兑换
          that.buyBook();

        } else if (res.cancel) {
          // 取消
        }
      }
    });
  },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        let _showInfo = {};
        let that = this;

        for (let key in options) {
            _showInfo[key] = decodeURIComponent(options[key]);
        }

        that.setData({
            showInfo: _showInfo
        });

        that.getPageData();


    },

    // 从上级页面返回时 重新拉去详情列表
    backRefreshPage: function() {

        let that = this;
        that.setData({
            detailLoading: true
        });

        that.getPageData();

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
      if (wx.getStorageSync('isFromBack')) {
          wx.removeStorageSync('isFromBack')
          this.backRefreshPage();
      }
      let that = this;
      wx.getSystemInfo({
          success: function (res) {
          console.info(res)
          let clientHeight = res.windowHeight,
            clientWidth = res.windowWidth,
            rpxR = 750 / clientWidth;
          var calc = clientHeight * rpxR;
          console.log(calc)
          that.setData({
            windowHeight: calc
          });
         }
      });
    }
});