// 获取服务器接口地址
const api = require('../../config/config.js');
// 获取app应用实例
const app = getApp();


Page({
  /**
   * 页面的初始数据
   */
  data: {
    hideHeader: true,
    hideBottom: true,
    showsList: [], // 列表显示的数据源
    allPages: '',    // 总页数
    currentPage: 1,  // 当前页数  默认是1
    loadMoreData: '加载更多……',
    showLoading: true,       // 是否显示loading态,
    cities: ['成都', '重庆', '北京', '上海', '广州', '深圳'],
    citiesVisible: false,
    curCity: '成都'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var date = new Date();
    this.getData();
  },
  // 上拉加载更多
  loadMore: function() {
    var self = this;
    // 当前页是最后一页
    if (self.data.currentPage == self.data.allPages) {
      self.setData({
        loadMoreData: '已经到顶'
      })
      return;
    }
    setTimeout(function () {
      console.log('上拉加载更多');
      var tempCurrentPage = self.data.currentPage;
      tempCurrentPage = tempCurrentPage + 1;
      self.setData({
        currentPage: tempCurrentPage,
        hideBottom: false
      })
      self.getData();
    }, 300);
  },
  // 下拉刷新
  refresh: function(e) {
    var self = this;
    setTimeout(function () {
      console.log('下拉刷新');
      self.setData({
        currentPage: 1,
        hideHeader: false
      })
      self.getData();
    }, 300);
  },
  // 获取数据  pageIndex：页码参数
  getData: function () {
    var self = this;
    var pageIndex = self.data.currentPage;
    let that = this;
    setTimeout(function () {
      that.setData({
        showsList: [{
          id: 1,
          name: '中秋晚会',
          poster: 'http://mz.djmall.xmisp.cn/files/product/20161213/148162245074.jpg',
          startTime: '2018-10-31',
          address: '東郊音樂花園',
          city: '成都',
          price: '200 - 500'
        },
          {
            id: 2,
            name: '中秋晚会2',
            poster: 'http://mz.djmall.xmisp.cn/files/product/20161201/14805828016.jpg',
            startTime: '2018-10-31',
            address: '東郊音樂花園',
            city: '成都',
            price: '500'
          }],
        showLoading: false,
        hideHeader: true,
        hideBottom: true
      });
    }, 1000);
    // wx.request({
    //   url: api.getShowsUrl,
    //   data: {
    //     page: pageIndex
    //   },
    //   success: function (res) {
    //     let data = res.data;
    //     // console.log(data);

    //     if (data.result) {
    //       setTimeout(function () {
    //         that.setData({
    //           showList: data.data,
    //           showLoading: false
    //         });
    //       }, 800);
    //     }

    //   },
    //   error: function (err) {
    //     console.log(err);
    //   }
    // });    
  },
  showCities () {
    this.setData({
      citiesVisible: true
    })
  },
  changeCity (val) {
    console.info(val)
    this.setData({
      curCity: val.detail.value,
      citiesVisible: false
    })
  },
  goDetail: function (ev) {

    let info = ev.currentTarget.dataset;

    let navigateUrl = '../detail/detail?';

    for (let key in info) {
      info[key] = encodeURIComponent(info[key]);
      navigateUrl += key + '=' + info[key] + '&';
    }

    navigateUrl = navigateUrl.substring(0, navigateUrl.length - 1);

    wx.navigateTo({
      url: navigateUrl
    });
  }
});