// components/dropdown/dropdown.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    visible: Boolean
  },

  /**
   * 组件的初始数据
   */
  data: {
    
  },

  /**q1
   * 
   * 组件的方法列表
   */
  methods: {
    toggleShow() {
      // 自定义组件向父组件传值 
      // let val = data,
      // my_event_detail = {
      //   val: val
      // }
      // myevent自定义名称事件，父组件中使用
      this.triggerEvent('toggle')
    },
  }
})
