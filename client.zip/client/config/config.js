// 服务器域名
const baseUrl 			= 'http://192.168.0.104:10001/v1/';
// 查询当前用户是否已经购买该书籍并返回评论列表接口
const queryShowUrl 		= baseUrl + 'user/show/detail';
// 登录接口
const loginUrl 			= baseUrl + 'user/login';
// 获取当前用户已购书籍接口
const getBoughtBooksUrl = baseUrl + 'api/user/getBoughtBooks';
// 获取票据列表
const queryTicketsUrl = baseUrl + 'user/ticketType/list';
//获取show列表
const getShowsUrl = baseUrl + 'user/show/list';
//下订单
const addOrder = baseUrl + 'user/order/create'


module.exports = {
	loginUrl: 			loginUrl,
  queryTicketsUrl: queryTicketsUrl,
  getShowsUrl: getShowsUrl,
  queryShowUrl: queryShowUrl,
  addOrder: addOrder
};
