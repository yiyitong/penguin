// 服务器域名
const baseUrl 			= 'http://192.168.0.103:10001/v1/';
// 获取书籍信息接口地址(可选择全部或单个书籍)
const getBooksUrl 		= baseUrl + 'api/book/getBooks';
// 写评论接口
const commentUrl 		= baseUrl + 'api/comment/write';
// 查询当前用户是否已经购买该书籍并返回评论列表接口
const queryShowUrl 		= baseUrl + 'api/user/show/detail';
// 登录接口
const loginUrl 			= baseUrl + 'user/login';
// 获取当前用户已购书籍接口
const getBoughtBooksUrl = baseUrl + 'api/user/getBoughtBooks';
// 获取票据列表
const queryTicketsUrl = baseUrl + 'show/tickets/list';

const getShowsUrl = baseUrl + 'user/show/list'


module.exports = {
	getBooksUrl: 		getBooksUrl,
	commentUrl: 		commentUrl,
	loginUrl: 			loginUrl,
	getBoughtBooksUrl: 	getBoughtBooksUrl,
  queryTicketsUrl: queryTicketsUrl,
  getShowsUrl: getShowsUrl,
  queryShowUrl: queryShowUrl 
};
