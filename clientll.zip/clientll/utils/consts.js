var ORDER_STAT = {
  Unpaid: '待付款',
  Paid: '待验票',
  Used: '已完成',
  Expired: '已过期'
}

module.exports = {
  ORDER_STAT: ORDER_STAT
}