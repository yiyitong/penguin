// pages/detail/detail.js

const app = getApp();
const api = require('../../config/config.js');

Page({

    /**
     * 页面的初始数据
     */
    data: {
      detailList: [],        // 评论列表
      ticketList: [],
      showInfo: {},           // 书籍信息
      detailLoading: true,
      buyDialogVisible: false,
      ticketsLoading: true,
      windowHeight: 300,
      count: 1,
      totalPrice: 0,
      minCount: 1,
      maxCount: 0,
      curTicket: {},
      userInfo: {},
      curDate: '',
      periods:[],
      curPeriod: '',
      startDate: '',
      endDate: '',
      availTickets: [],
      showPrice: ''
    },
    bindDateChange: function (e) {
      console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        curDate: e.detail.value
      })
      this.filterTickets();
    },
    // 获取演出详情信息
    getPageData: function() {

      let that = this;
      let requestData = {
          showId: that.data.showInfo.id
      };
        wx.request({
          url: api.queryShowUrl,
          method: 'GET',
          data: requestData,
            success: function(res) {
                if (res.data.result) {
                    that.setData({
                        detailList: res.data.data || []
                    });
                    setTimeout(function() {
                        that.setData({
                            detailLoading: false
                        });
                    }, 500);
                } else {
                    that.showInfo('返回数据异常');
                }
            },
            fail: function(error) {
                that.showInfo('请求失败');
            }
        });
    },


    showInfo: function(info, icon = 'none') {
        wx.showToast({
            title: info,
            icon: icon,
            duration: 1500,
            mask: true
        });
    },
    showBuyDialog () {
      this.getShowTickets();
      this.setData({
        buyDialogVisible: true
      });
    },
  hideBuyDialog() {
      this.setData({
        buyDialogVisible: false
      });
  },
  // 获取演出详情信息
  getShowTickets: function () {
    console.info('getShowTickets')
    let that = this;
    let requestData = {
      showId: that.data.showInfo.id
    };
    wx.request({
      url: api.queryTicketsUrl,
      method: 'GET',
      data: requestData,
      success: function(res) {
          if (res.data.result) {
              that.setData({
                  ticketList: res.data.data
              });
              that.filterTickets();
              setTimeout(function() {
                  that.setData({
                      ticketsLoading: false
                  });
              }, 500);
          } else {
              app.showInfo('返回数据异常');
          }
        },
        fail: function(error) {
            that.showInfo('请求失败');
        }
    });
  },

  setCurTicket() {
    let ticket = this.data.availTickets.find(tick => tick.restCount > 0);
    if (ticket) {
      let restCount = ticket ? ticket.restCount : 0;
      this.setData({
        maxCount: restCount,
        curTicket: ticket,
        totalPrice: ticket ? ticket.price : 0
      });
    }
  },
  getTicketItem (id) {
    return this.data.ticketList.find(tick => tick.id == id)
  },
  changePeriod (ev) {
    console.info('changePeriod:', ev.detail.value);
    this.setData({
      curPeriod: ev.detail.value
    });
    this.filterTickets()
  },
  changeTicket (ev) {
    console.info('changeTicket:', ev.detail.value, this.data.count)
    let ticket = this.getTicketItem(ev.detail.value)
    this.setData({
      maxCount: ticket.restCount,
      curTicket: ticket,
      totalPrice: this.data.count * ticket.price
    });
  },
  handleCountChange (val) {
    this.setData({
      count: val.detail,
      totalPrice: val.detail * this.data.curTicket.price
    });
  },
  onGotUserInfo (e) {
    this.setData({
      userInfo: e.detail.userInfo
    })
    wx.showLoading({
      title: '登录中...',
      mask: true
    });
    app.doLogin(() => this.gotoBuy());
  },
  gotoBuy () {
    wx.hideLoading()
    //下订单
    let that = this;
    let requestData = {
      showId: that.data.showInfo.id,
      total: that.data.totalPrice,
      orderTickets: [{
        ticketId: that.data.curTicket.id,
        amount: that.data.count
      }]
    }
    let loginFlag = wx.getStorageSync('loginFlag');
    console.info('gotoBuy:', requestData);
    wx.request({
      url: api.addOrder,
      method: 'POST',
      header: { 'x-token': loginFlag },
      data: requestData,
      success: (({data}) => {
        console.info(data)
        if (data.result) {
          wx.requestPayment({
            timeStamp: data.data['timeStamp'],
            nonceStr: data.data['nonceStr'],
            'package': 'prepay_id=' + data.data['prepayId'],
            signType: data.data['signType'],
            paySign: data.data['paySign'],
            totalFee: that.data.totalPrice,
            'success': function (successret) {
              console.log('支付成功');
              that.setData({
                buyDialogVisible: false
              });
              app.showInfo('支付成功! 您可以在个人中心查看您的订单。', successret);
              // jump to order
              let orderId = data.data['orderId'];
              let navigateUrl = '../orderDetail/orderDetail?id=' + orderId;
              wx.navigateTo({
                url: navigateUrl
              });
            }, 
            'fail': function (res) {
              app.showInfo('支付失败! 我们将为保留您的订票半个小时，请在半小时内完成支付。', res);
                }
            });
          } else {
              app.showInfo('返回数据异常');
          }
      }),
      fail: function(error) {
          app.showInfo('请求失败');
      }
    });
  },
  selectTicket (e) {
    var id = e.currentTarget.dataset.id;
    let curTicket = this.data.ticketList.find(el => el.id === id);
    this.setData({
      curTicket: curTicket
    });
  },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function(options) {
        let _showInfo = {};
        let that = this;

        for (let key in options) {
            _showInfo[key] = decodeURIComponent(options[key]);
        }
      let dates = _showInfo.displayTime.split('-');
      let util = require('../../utils/util.js');
      console.info('dates:', _showInfo)

      let showPrice = '￥0'
      if (_showInfo.minPrice !== 'null') {
        showPrice = _showInfo.minPrice === _showInfo.maxPrice ? '￥' + _showInfo.minPrice / 100 : '￥' + _showInfo.minPrice / 100 + ' - ￥' + _showInfo.maxPrice / 100;
      }
        this.setData({
          showPrice: showPrice
        });
        if (dates && dates.length > 0) {
          this.setData({
            startDate: util.formatWxDate(dates[0]),
            endDate: util.formatWxDate(dates[1]),
            curDate: util.formatWxDate(dates[0])
          })
        }
        that.setData({
          showInfo: _showInfo,
          periods: _showInfo.period && _showInfo.period !== 'null' ? _showInfo.period.split(',') : [],
          curPeriod: _showInfo.period && _showInfo.period !== 'null'? _showInfo.period.split(',')[0] : ''
        });

        that.getPageData();
      let userStorageInfo = wx.getStorageSync('userInfo');
      if (userStorageInfo) {
        that.setData({
          userInfo: JSON.parse(userStorageInfo)
        });
      }
    },
    filterTickets () {
      console.log(this.data.curDate);
      let curDate = Date.parse(new Date(this.data.curDate.replace(/-/g, '/'))) ;
      let curPeriod = this.data.curPeriod;
      let tickets = this.data.ticketList.filter(el => el.startTime === curDate && el.period === curPeriod);
      console.info(curDate, curPeriod, tickets, this.data.ticketList)
      this.setData({
        availTickets: tickets
      });
      this.setCurTicket();
    },
    // 从上级页面返回时 重新拉去详情列表
    backRefreshPage: function() {

        let that = this;
        that.setData({
            detailLoading: true
        });

        that.getPageData();

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function() {
      if (wx.getStorageSync('isFromBack')) {
          wx.removeStorageSync('isFromBack')
          this.backRefreshPage();
      }
      let that = this;
      wx.getSystemInfo({
          success: function (res) {
          console.info(res)
          let clientHeight = res.windowHeight,
            clientWidth = res.windowWidth,
            rpxR = 750 / clientWidth;
          var calc = clientHeight * rpxR;
          console.log(calc)
          that.setData({
            windowHeight: calc
          });
         }
      });
    },
  onShareAppMessage () {
    let info = this.data.showInfo;
    let navigateUrl = '/pages/detail/detail?';
    for (let key in info) {
      info[key] = encodeURIComponent(info[key]);
      navigateUrl += key + '=' + info[key] + '&';
    }
    navigateUrl = navigateUrl.substring(0, navigateUrl.length - 1);
    console.info(navigateUrl, this.data.showInfo)
    return {
      title: `您的好友分享以下演出给您：`,
      path: navigateUrl,
      imageUrl: decodeURIComponent(this.data.showInfo.poster)
    }
  }
});