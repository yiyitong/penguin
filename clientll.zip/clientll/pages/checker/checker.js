// pages/checkor/checkor.js
let app = getApp();
const api = require('../../config/config.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    orderInfo: {},
    checkResultStr: '',
    param: ''
  },
  check (reqData) {
    let that = this;
    console.log('after login:', reqData)
    reqData.showId = this.data.orderInfo.showId;
    reqData.orderId = this.data.orderInfo.id;
    let orderInfo = this.data.orderInfo
    wx.request({
      url: api.checkTicketUrl,
      data: reqData,
      success: ({data}) => {
        if (data.result) {
          wx.hideLoading();
          orderInfo.showName = data.data.showName;
          orderInfo['ticketName'] = data.data.ticketName;
          orderInfo.amount = data.data.amount;
          orderInfo.totalFee = data.data.totalFee;
          that.setData({
            checkResultStr: '验票成功！',
            orderInfo: orderInfo
          })
        } else {
          let res = '验票失败！'
          if (data.code === 'SERVICE_0010') {
            res += '此票已验过，不可重复提供验票。'
          } else if (data.code === 'SERVICE_0008') {
            res += '此票已验过，您没有验票权限。'
          } else if (data.code === 'SERVICE_0009') {
            res += '此票已验过，订单信息获取失败。'
          } else if (data.code === 'SERVICE_0011') {
            res += '此票已验过，订单状态异常。'
          } 
          that.setData({
            checkResultStr: res
          })
          wx.hideLoading();
        }
      },
      fail: () => {
        that.setData({
          checkResultStr: '验票失败！'
        })
        wx.hideLoading();
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let _item = {};
    let that = this;
    let scanUrl = decodeURIComponent(options.q);
    let matches = scanUrl.match(/=\d+/g);
    if (matches.length === 2) {
      _item.showId = parseInt(matches[0].substr(1))
      _item.id = parseInt(matches[1].substr(1))
    }
    console.info('checker load:', _item)
    this.setData({
      orderInfo: _item,
      param: _item.showId
    });
    wx.showLoading({
      title: '验票中，请稍候...',
    })
    app.doLogin(this.check)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})