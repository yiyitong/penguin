// pages/myOrders/myOrders.js
// 获取服务器接口地址
const api = require('../../config/config.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    currtab: 0,
    swipertab: [{ name: '全部', index: 0, key: '' },
      { name: '待付款', index: 1, key: 'Unpaid' }, { name: '待验票', index: 2, key: 'Paid' }, { name: '已完成', index: 3, key: 'Used' }],
    orderList: [],
    totalPage: 0,
    currentPage: 1,
    ordersLoading: false,
    windowHeight: 1208
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 页面渲染完成
    this.getDeviceInfo()
    this.orderShow(true)
  },

  getDeviceInfo: function () {
    let that = this
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          deviceW: res.windowWidth,
          deviceH: res.windowHeight
        })
      }
    })
  },

  /**
  * @Explain：选项卡点击切换
  */
  tabSwitch: function (e) {
    var that = this
    if (this.data.currtab === e.target.dataset.current) {
      return false
    } else {
      that.setData({
        currtab: e.target.dataset.current
      })
    }
  },

  tabChange: function (e) {
    this.setData({
      currtab: e.detail.current,
      orderList: []
    })
    this.orderShow(true)
  },

  orderShow: function (refresh) {
    let key = this.data.swipertab[this.data.currtab].key;
    this.initOrderList(key, refresh);
  },
  initOrderList (key, refresh) {
    let that = this;
    var pageIndex = that.data.currentPage;
    let loginFlag = wx.getStorageSync('loginFlag');
    if (refresh) {
      this.setData({
        orderList: []
      })
    }
    // setTimeout(function () {
    //   that.setData({
    //     orderList: [{
    //       id: 1,
    //       showName: '中秋晚会',
    //       poster: 'http://mz.djmall.xmisp.cn/files/product/20161213/148162245074.jpg',
    //       ticketName: '早鸟票',
    //       ticketCount: 2,
    //       price: 150,
    //       status: 0
    //     },
    //     {
    //       id: 2,
    //       showName: '中秋晚会2',
    //       poster: 'http://mz.djmall.xmisp.cn/files/product/20161213/148162245074.jpg',
    //       ticketName: '早鸟票',
    //       ticketCount: 2,
    //       price: 100,
    //       status: 1
    //       },
    //       {
    //         id: 3,
    //         showName: '中秋晚会2',
    //         poster: 'http://mz.djmall.xmisp.cn/files/product/20161213/148162245074.jpg',
    //         ticketName: '早鸟票',
    //         ticketCount: 2,
    //         price: 100,
    //         status: 2
    //       },
    //       {
    //         id: 4,
    //         showName: '中秋晚会2',
    //         poster: 'http://mz.djmall.xmisp.cn/files/product/20161213/148162245074.jpg',
    //         ticketName: '早鸟票',
    //         ticketCount: 2,
    //         price: 100,
    //         status: 3
    //       }]
    //   }
    //   );
    // }, 1000);
    this.setData({
      ordersLoading: true
    })
    wx.request({
      url: api.queryOrderList,
      header: { 'x-token': loginFlag},
      data: {
        page: '{"index":' + pageIndex + ', "size": 10}',
        status: key === 'all' ? '': key
      },
      success: function (res) {
        let data = res.data;
        console.log('orders:', data);
        let pages = Math.ceil(data.data.total / 10);
        if (data.result) {
          setTimeout(function () {
            let orders = [];
            if (refresh) {
              orders = data.data.records;
            } else {
              orders = [...that.data.orderList, ...data.data.records];
            }
            console.info(orders)
            that.setData({
              orderList: orders,
              totalPage: pages,
              ordersLoading: false
            });
          }, 800);
        }
      }
    });
  },
  loadMore () {
    var self = this;
    // 当前页是最后一页
    if (self.data.currentPage == self.data.totalPage) {
      return;
    }
    setTimeout(function () {
      var tempCurrentPage = self.data.currentPage;
      tempCurrentPage = tempCurrentPage + 1;
      self.setData({
        currentPage: tempCurrentPage
      })
      self.orderShow();
    }, 300);
  },
  payForTicket (ticketId) {
    //TODO：支付
  },
  checkTicket (ev) {
    let info = ev.currentTarget.dataset;
    let navigateUrl = '../orderDetail/orderDetail?';
    for (let key in info) {
      info[key] = encodeURIComponent(info[key]);
      navigateUrl += key + '=' + info[key] + '&';
    }

    navigateUrl = navigateUrl.substring(0, navigateUrl.length - 1);

    wx.navigateTo({
      url: navigateUrl
    });
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    wx.getSystemInfo({
      success: (res) => {
        let clientHeight = res.windowHeight,
          clientWidth = res.windowWidth,
          rpxR = 750 / clientWidth;
        var calc = clientHeight * rpxR;
        console.log(calc)
        this.setData({
          windowHeight: calc
        });
      }
    });
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
