// pages/orderDetail/orderDetail.js
const api = require('../../config/config.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    item: {},
    orderId: -1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let orderId = -1;
    orderId = decodeURIComponent(options.id);
    this.setData({
      orderId: orderId
    });
  },
  drawQrCode () {
    var drawQrcode = require('../../utils/weapp.qrcode.min.js');
    wx.getSystemInfo({
      success: (res) => {
        let clientHeight = res.windowHeight,
          clientWidth = res.windowWidth,
          rpxR = clientWidth / 750;
        let cWidth = 245 * rpxR;
        console.info(this.data.item)
        drawQrcode({
          width: cWidth,
          height: cWidth,
          canvasId: 'myQrcode',
          text: this.data.item.qrCodeUrl
        });
      }
    });
  },
  /**测试用验票函数 to be delete */
  checkTicket(ev) {
    let info = ev.currentTarget.dataset;
    let navigateUrl = '/pages/checker/checker?';
    for (let key in info) {
      info[key] = encodeURIComponent(info[key]);
      navigateUrl += key + '=' + info[key] + '&';
    }

    navigateUrl = navigateUrl.substring(0, navigateUrl.length - 1);

    wx.navigateTo({
      url: navigateUrl
    });
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    let that = this;
    let loginFlag = wx.getStorageSync('loginFlag');
    wx.request({
      url: api.queryOrderDetailUrl,
      header: { 'x-token': loginFlag },
      data: {
        orderId: that.data.orderId
      },
      success: ({ data }) => {
        if (data.result) {
          let util = require('../../utils/util.js');
          data.data.startTime = util.formatDate(data.data.startTime);
          that.setData({
            item: data.data
          })
          that.drawQrCode();
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})