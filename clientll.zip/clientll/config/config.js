// 服务器域名
const baseUrl = 'https://weixinapp.runtotheeast.net/api/v1/';
// 查询当前用户是否已经购买该书籍并返回评论列表接口
const queryShowUrl 		= baseUrl + 'user/show/detail';
// 登录接口
const loginUrl 			= baseUrl + 'user/login';
// 获取当前用户已购书籍接口
const getBoughtBooksUrl = baseUrl + 'api/user/getBoughtBooks';
// 获取票据列表
const queryTicketsUrl = baseUrl + 'user/ticketType/list';
//获取show列表
const getShowsUrl = baseUrl + 'user/show/list';
//下订单
const addOrder = baseUrl + 'user/order/create'
//订单列表
const queryOrderList = baseUrl + 'user/order/list'
//删除订单
const deleteOrderUrl = baseUrl + 'user/order/delete'
//支付订单
const payOrderUrl = baseUrl + 'user/order/pay'
//检测token是否失效
const checkTokenUrl = baseUrl + 'auth/token'
//验票
const checkTicketUrl = baseUrl + 'check/order'
//获取订单详情
const queryOrderDetailUrl = baseUrl + 'user/order/detail'

module.exports = {
	loginUrl: 			loginUrl,
  queryTicketsUrl: queryTicketsUrl,
  getShowsUrl: getShowsUrl,
  queryShowUrl: queryShowUrl,
  addOrder: addOrder,
  queryOrderList: queryOrderList,
  deleteOrderUrl: deleteOrderUrl,
  payOrderUrl: payOrderUrl,
  checkTokenUrl: checkTokenUrl,
  checkTicketUrl: checkTicketUrl,
  queryOrderDetailUrl: queryOrderDetailUrl
};
