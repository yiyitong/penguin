// components/orderlist/orderlist.js
const api = require('../../config/config.js');
var app = getApp();
import { ORDER_STAT} from '../../utils/consts.js'
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    records: Array
  },

  /**
   * 组件的初始数据
   */
  data: {
    OrderStat: ORDER_STAT
  },

  /**
   * 组件的方法列表
   */
  methods: {
    checkTicket(ev) {
      let info = ev.currentTarget.dataset;
      let navigateUrl = '../orderDetail/orderDetail?';
      for (let key in info) {
        info[key] = encodeURIComponent(info[key]);
        navigateUrl += key + '=' + info[key] + '&';
      }

      navigateUrl = navigateUrl.substring(0, navigateUrl.length - 1);

      wx.navigateTo({
        url: navigateUrl
      });
    },
    loadMore() {
      this.triggerEvent('more')
    },
    delTicket(ev) {
      let id = ev.currentTarget.dataset.id;
      let that = this;
      let loginFlag = wx.getStorageSync('loginFlag');
      wx.showModal({
        title: '提示',
        content: '您将删除该订单？',
        success(res) {
          if (res.confirm) {
            wx.request({
              url: api.deleteOrderUrl,
              header: { 'x-token': loginFlag },
              method: 'POST',
              data: [id],
              success: () => {
                wx.showToast({
                  title: '删除成功！',
                  icon: 'none',
                  duration: 1500,
                  mask: true
                });
                that.triggerEvent('refresh')
              },
              fail: () => {
                wx.showToast({
                  title: '删除失败！',
                  icon: 'none',
                  duration: 1500,
                  mask: true
                });
              }
            })
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    },
    payForOrder (ev) {
      let data = ev.currentTarget.dataset
      let that = this;
      wx.requestPayment({
        timeStamp: data['timeStamp'],
        nonceStr: data['nonceStr'],
        'package': 'prepay_id=' + data['prepayId'],
        signType: data['signType'],
        paySign: data['paySign'],
        'success': function (successret) {
          app.showInfo('支付成功! 您可以在个人中心查看您的订单。');
        }, 'fail': function (res) {
          app.showInfo('支付失败! 我们将为保留您的订票半个小时，请在半小时内完成支付。', res);
        }
      });
    }
  }
})
