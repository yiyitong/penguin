// components/numberinput/numberinput.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    min: Number,
    max: Number
  },

  /**
   * 组件的初始数据
   */
  data: {
    number: 1,
    disabledNext: false,
    disabledPrev: false
  },

  /**
   * 组件的方法列表
   */
  methods: {
    prevNum() {
      var min = this.properties.min;
      this.setData({
        number: this.data.number <= min ? min : this.data.number - 1
      });
      this.triggerEvent('change', this.data.number)
    },
    nextNum() {
      var max = this.properties.max;
      this.setData({
        number: this.data.number >= max ? max : this.data.number + 1
      });
      this.triggerEvent('change', this.data.number)
    },
    handleInput (val) {
      var min = this.properties.min;
      var max = this.properties.max;
      var iVa = parseInt(val.detail.value)
      let newVal = iVa > max ? max : (iVa < min ? min : iVa);
      console.info('handleinput:', newVal);
      this.setData({
        number: newVal
      }) 
      this.triggerEvent('change', this.data.number)
    }
  }
})
